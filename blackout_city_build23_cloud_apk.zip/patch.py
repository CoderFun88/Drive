from pathlib import Path
p=Path('/mnt/data/b09work/app/src/main/assets/index.html')
s=p.read_text()
s=s.replace('<title>BLACKOUT CITY — Build 07</title>','<title>BLACKOUT CITY — Build 09</title>')
s=s.replace('OPEN WORLD · FREE ROAM · BUILD 07','OPEN WORLD · FREE ROAM · BUILD 09')
s=s.replace('OPEN WORLD · FREE ROAM · BUILD 07','OPEN WORLD · FREE ROAM · BUILD 09')
s=s.replace('<p class="small">Android-3D-Prototyp · benötigt Internet zum Laden der Grafikbibliothek.</p>','<p class="small">BUILD 0.9 · Originalmusik und Spielsounds lokal integriert. Grafikbibliothek benötigt Internet.</p>')
old='''// Original mellow synth radio, starts only while driving.
let audioCtx=null,radioEnabled=true,radioPlaying=false,radioTimer=null,radioNodes=[];
function initRadioAudio(){if(audioCtx)return;const AC=window.AudioContext||window.webkitAudioContext;if(AC)audioCtx=new AC()}
function stopRadio(){if(!audioCtx||!radioPlaying)return;radioPlaying=false;if(radioTimer)clearInterval(radioTimer);radioTimer=null;radioNodes.forEach(n=>{try{n.stop?.()}catch(e){}try{n.disconnect?.()}catch(e){}});radioNodes=[];document.getElementById('radioStatus').textContent='RETRO FM · PAUSIERT'}
function note(freq,start,duration,type,vol,cut){const o=audioCtx.createOscillator(),g=audioCtx.createGain(),f=audioCtx.createBiquadFilter();o.type=type;o.frequency.setValueAtTime(freq,start);f.type='lowpass';f.frequency.setValueAtTime(cut,start);g.gain.setValueAtTime(.0001,start);g.gain.linearRampToValueAtTime(vol,start+.15);g.gain.setTargetAtTime(.0001,start+duration-.18,.12);o.connect(f);f.connect(g);g.connect(audioCtx.destination);o.start(start);o.stop(start+duration);radioNodes.push(o,f,g)}
function radioBar(){if(!audioCtx||!radioPlaying||audioCtx.state!=='running')return;const now=audioCtx.currentTime,beat=60/82,bar=beat*4,prog=[[110,164.81,220],[87.31,130.81,174.61],[98,146.83,196],[73.42,110,146.83]],idx=Math.floor(performance.now()/1000/bar),ch=prog[idx%4];ch.forEach((f,i)=>note(f,now,bar*1.8,'sawtooth',i===0?.01:.007,820));const seq=[1,1.25,1.5,1.25,1.12,1.5,1.25,1];for(let i=0;i<8;i++)note(ch[2]*seq[(i+idx)%8],now+i*beat*.5,beat*.65,'triangle',.01,1450)}
function startRadio(){if(!audioCtx||radioPlaying||!radioEnabled||!driving)return;audioCtx.resume();radioPlaying=true;document.getElementById('radioStatus').textContent='RETRO FM · 80s NIGHT DRIVE';radioBar();radioTimer=setInterval(radioBar,60/82*4000)}
function syncRadio(){if(driving&&radioEnabled)startRadio();else stopRadio()}
'''
new='''// BUILD 09 audio: locally bundled original CC0-dedicated music and sound effects.
const radioAudio=new Audio('audio/retro-fm.mp3');radioAudio.loop=true;radioAudio.volume=.24;radioAudio.preload='auto';
const cityAudio=new Audio('audio/city-ambience.mp3');cityAudio.loop=true;cityAudio.volume=.20;cityAudio.preload='auto';
const engineAudio=new Audio('audio/engine-loop.mp3');engineAudio.loop=true;engineAudio.volume=.08;engineAudio.preload='auto';
const footAudio=new Audio('audio/footsteps.mp3');footAudio.volume=.28;footAudio.preload='auto';
let radioEnabled=true,radioPlaying=false,footstepClock=0,audioUnlocked=false;
function initGameAudio(){audioUnlocked=true;[cityAudio].forEach(a=>{a.play().catch(()=>{})});syncRadio();syncEngine()}
function startRadio(){if(radioPlaying||!radioEnabled||!driving)return;radioAudio.currentTime=radioAudio.currentTime||0;radioAudio.play().then(()=>{radioPlaying=true;document.getElementById('radioStatus').textContent='RETRO FM · CC0 SYNTHWAVE'}).catch(()=>{document.getElementById('radioStatus').textContent='RETRO FM · TIPPE ERNEUT'})}
function stopRadio(){radioAudio.pause();radioPlaying=false;document.getElementById('radioStatus').textContent='RETRO FM · PAUSIERT'}
function syncRadio(){if(driving&&radioEnabled)startRadio();else stopRadio()}
function syncEngine(){if(driving){engineAudio.play().catch(()=>{});engineAudio.volume=Math.min(.18,.055+Math.abs(carSpeed)/34*.09)}else{engineAudio.pause();engineAudio.currentTime=0}}
function updateGameAudio(dt,moving){if(!audioUnlocked)return;if(driving){if(engineAudio.paused)syncEngine();engineAudio.volume=Math.min(.19,.06+Math.abs(carSpeed)/34*.11)}else{if(moving){footstepClock-=dt;if(footstepClock<=0){footAudio.currentTime=0;footAudio.play().catch(()=>{});footstepClock=run?.34:.48}}else footstepClock=0}}
function pauseAllGameAudio(){radioAudio.pause();cityAudio.pause();engineAudio.pause();radioPlaying=false}
'''
if old not in s: raise SystemExit('audio block not found')
s=s.replace(old,new)
s=s.replace("if(best){activeCar=best;driving=true;player.visible=false;carSpeed=0;say('EINGESTIEGEN · MOTOR LÄUFT');syncRadio()}else", "if(best){activeCar=best;driving=true;player.visible=false;carSpeed=0;say('EINGESTIEGEN · MOTOR LÄUFT');syncRadio();syncEngine()}else")
s=s.replace("player.visible=true;driving=false;activeCar=null;carSpeed=0;say('AUSGESTIEGEN');syncRadio()", "player.visible=true;driving=false;activeCar=null;carSpeed=0;say('AUSGESTIEGEN');syncRadio();syncEngine()")
s=s.replace("if(!driving){\n  const forward", "if(!driving){\n  const forward")
# insert update audio at end of update before closing after speed text
needle="document.getElementById('speed').textContent=driving?`FAHRT · ${Math.round(Math.abs(carSpeed)*4)} KM/H`:'ZU FUSS';\n}"
repl="document.getElementById('speed').textContent=driving?`FAHRT · ${Math.round(Math.abs(carSpeed)*4)} KM/H`:'ZU FUSS';\n updateGameAudio(dt,!driving&&(move.lengthSq()>.015||keys.w||keys.a||keys.s||keys.d));\n}"
if needle not in s: raise SystemExit('update end not found')
s=s.replace(needle,repl)
s=s.replace("if(document.hidden){running=false;stopRadio()}else if(!running", "if(document.hidden){running=false;pauseAllGameAudio()}else if(!running")
s=s.replace("document.getElementById('start').onclick=()=>{initRadioAudio();if(audioCtx)audioCtx.resume();document.getElementById('overlay').style.display='none';running=true;last=performance.now();requestAnimationFrame(loop)};", "document.getElementById('start').onclick=()=>{initGameAudio();document.getElementById('overlay').style.display='none';running=true;last=performance.now();requestAnimationFrame(loop)};")
p.write_text(s)
# Build metadata
p=Path('/mnt/data/b09work/app/build.gradle'); s=p.read_text().replace('versionCode 8','versionCode 9').replace("versionName '0.8'","versionName '0.9'"); p.write_text(s)
# Workflow zip filename
p=Path('/mnt/data/b09work/.github/workflows/android-apk.yml'); s=p.read_text().replace('blackout_city_build08_cloud_apk.zip','blackout_city_build09_cloud_apk.zip'); p.write_text(s)
# Documentation
(out/'AUDIO_ASSETS_README.txt').write_text('''BLACKOUT CITY BUILD 09 — AUDIO / LICENSE NOTES\n\nBundled files (all stored locally in the APK):\n- retro-fm.mp3: original instrumental synthwave composition created for Blackout City; dedicated to CC0 1.0 / public domain. Faster 112 BPM driving beat.\n- city-ambience.mp3: original synthesized urban traffic ambience, CC0 1.0.\n- engine-loop.mp3: original synthesized idling engine loop, CC0 1.0.\n- footsteps.mp3: original synthesized footstep effect, CC0 1.0.\n\nThese are original generated audio assets, not recordings or tracks copied from third parties. They are dedicated to the public domain under CC0 1.0. No attribution is required. No GTA music or sound recordings are included.\n\nPlayback: city ambience runs while playing; radio starts on entering a car and pauses on exit; radio toggle is available in the HUD; engine loop follows vehicle use; footsteps trigger while walking/running.\n''')
