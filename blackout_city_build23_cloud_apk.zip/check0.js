
// Build 21: report the real startup failure instead of showing a generic engine message.
window.__bcEngineReady = false;
window.__bcEngineError = '';
window.__bcShowEngineError = function(message){
  const status = document.querySelector('#card .small');
  const button = document.getElementById('start');
  window.__bcEngineError = String(message || 'Unbekannter Initialisierungsfehler');
  if (status) status.textContent = 'Grafikfehler: ' + window.__bcEngineError;
  if (button) { button.disabled = false; button.textContent = 'ERNEUT VERSUCHEN'; }
};
window.addEventListener('error', function(event){
  if (!window.__bcEngineReady) window.__bcShowEngineError(event.message || (event.filename ? event.filename + ':' + event.lineno : 'JavaScript-Ladefehler'));
});
window.addEventListener('unhandledrejection', function(event){
  if (!window.__bcEngineReady) window.__bcShowEngineError(event.reason && (event.reason.stack || event.reason.message) || event.reason || 'Promise-Fehler');
});
(function(){
  const button = document.getElementById('start');
  let waiting = false;
  button.addEventListener('click', function(){
    if (window.__bcEngineReady || waiting) return;
    waiting = true;
    button.disabled = true;
    button.textContent = 'GRAFIK WIRD GELADEN…';
    setTimeout(function(){
      if (!window.__bcEngineReady && !window.__bcEngineError) {
        window.__bcShowEngineError('Initialisierung dauert ungewöhnlich lange. Bitte Fehlerdetails prüfen.');
      }
      waiting = false;
    }, 10000);
  }, true);
})();
